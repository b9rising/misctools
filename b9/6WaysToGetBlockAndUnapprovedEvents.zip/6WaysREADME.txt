All of these scripts get data on "new unapproved file to computer" and "execution block (unapproved file)" events.

The "analysis" scripts get the basic data we use to deal with 95% of the "low hanging fruit" during an implementation project.

The "expanded" script generate huge output, but offer extra data that can help with troubleshooting complex issues or discerning subtle patterns.

The "sample" ones will randomly pull from only a sample of computers.  You adjust the percentage of total near the top.

The "aggregat" ones get the same data as the "analysis" ones, but instead of getting every single event they count the number of same/like events per computer and do not pull timestamps.

All scripts have variables at the top that allow you specify how many days worth of data to grab, and how many days back to start looking from.